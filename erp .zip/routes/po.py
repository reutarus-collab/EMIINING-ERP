from flask import Blueprint, request, jsonify
from services.db import db
from services.models import Supplier, PurchaseOrderHeader, PurchaseOrderLine, FeedIngredient
from services.po_service import create_purchase_order, post_goods_receipt

po_bp = Blueprint('po_bp', __name__)

@po_bp.route('/api/suppliers', methods=['GET', 'POST'])
def manage_suppliers():
    if request.method == 'POST':
        data = request.get_json()
        supplier = Supplier(name=data['name'], contact_info=data.get('contact_info', ''))
        db.session.add(supplier)
        db.session.commit()
        return jsonify({'status': 'success', 'supplier_id': supplier.id})
    
    suppliers = Supplier.query.all()
    return jsonify([{'id': s.id, 'name': s.name, 'contact_info': s.contact_info} for s in suppliers])

@po_bp.route('/api/po', methods=['POST'])
def create_po():
    try:
        data = request.get_json()
        po_number = create_purchase_order(data)
        return jsonify({'status': 'success', 'po_number': po_number})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@po_bp.route('/api/po/<int:po_id>/receive', methods=['POST'])
def receive_po(po_id):
    try:
        grn_data = request.get_json()
        grn_number = post_goods_receipt(po_id, grn_data)
        return jsonify({'status': 'success', 'grn_number': grn_number})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400

@po_bp.route('/api/po', methods=['GET'])
def list_pos():
    pos = PurchaseOrderHeader.query.order_by(PurchaseOrderHeader.order_date.desc()).limit(50).all()
    result = []
    for po in pos:
        supplier = db.session.get(Supplier, po.supplier_id)
        result.append({
            'id': po.id,
            'po_number': po.po_number,
            'supplier_name': supplier.name if supplier else 'Unknown',
            'total_amount': po.total_amount,
            'status': po.status,
            'created_at': po.order_date.strftime('%Y-%m-%d') if po.order_date else ''
        })
@po_bp.route('/api/po/<int:po_id>/lines', methods=['GET'])
def get_po_lines(po_id):
    po = PurchaseOrderHeader.query.get_or_404(po_id)
    lines = PurchaseOrderLine.query.filter_by(po_header_id=po.id).all()
    
    lines_data = []
    for l in lines:
        ing = db.session.get(FeedIngredient, l.ingredient_id)
        
        # Calculate how much of this line has already been received in previous GRNs
        from services.models import GoodsReceiptLine
        past_receipts = db.session.query(db.func.sum(GoodsReceiptLine.qty_accepted)).filter_by(po_line_id=l.id).scalar() or 0.0
        
        lines_data.append({
            'id': l.id,
            'item_name': ing.name if ing else 'Unknown',
            'qty_ordered': l.qty_ordered,
            'qty_received_so_far': past_receipts,
            'unit_cost': l.unit_cost
        })
        
    return jsonify({
        'id': po.id,
        'po_number': po.po_number,
        'status': po.status,
        'lines': lines_data
    })
    return jsonify(result)